
cats = {0.35}; %0.90; 0.95; 0.995};
%Physical constants
Tm = 27; %11.6164; %Tension of the material (in mg / ms^2)
tol = 1e-5;
name = sprintf('historialCoefOfRestitutionTm%g.csv', Tm);
for iii = 1:length(cats)
    rS = cats{iii}; %Radius of the sphere (in mm)
    vihigh = 0.5;
    vilow = 0;
    while vihigh - vilow > tol
        vi = (vihigh + vilow) / 2;
        r = mainFunction1_8(rS, Tm, ...
            'v_k'     , -abs(vi), ...
            'N'       , 150, ...
            'plotter' , false, ...
            'FileName', name, ...
            'exportData', true ...
            );
        if r > 1e+6
            vilow = vi;
        else
            vihigh = vi;
        end
    end
end